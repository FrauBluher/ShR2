// Setup Debug Environment
expRemoveAll
expAdd("dataIn_p" getNatural())
expAdd("dataOut_p" getNatural())
expAdd("err" getNatural())
