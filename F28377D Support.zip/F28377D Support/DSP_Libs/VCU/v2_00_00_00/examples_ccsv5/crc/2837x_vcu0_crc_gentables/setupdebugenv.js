// Setup Debug Environment
expRemoveAll

expAdd('pass',getNatural())
expAdd('fail',getNatural())
expAdd('crc8ResultC',getHex())
expAdd('crc16P1ResultC',getHex())
expAdd('crc16P2ResultC',getHex())
expAdd('crc32ResultC',getHex())
expAdd('crc8ResultVcu',getHex())
expAdd('crc16P1ResultVcu',getHex())
expAdd('crc16P2ResultVcu',getHex())
expAdd('crc32ResultVcu',getHex())
expAdd('crcResultLnk',getHex())
