// Setup Debug Environment
expRemoveAll

expAdd('pass',getNatural())
expAdd('fail',getNatural())
expAdd('CRC',getNatural())
expAdd('crcResultC_1',getHex())
expAdd('crcResultC_2',getHex())
expAdd('crcResultVcu_1',getHex())
expAdd('crcResultVcu_2',getHex())
expAdd('crcResultLnk',getHex())

