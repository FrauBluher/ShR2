// Setup Debug Environment
expRemoveAll

expAdd('pass',getNatural())
expAdd('fail',getNatural())
expAdd('CRC',getNatural())
expAdd('crcResultC',getHex())
expAdd('crcResultVcu',getHex())
expAdd('crcResultLnk',getHex())
