//Add watch window variables
expRemoveAll

expAdd "crc_c" getHex()
expAdd "crc_vcu" getHex()
expAdd "crc_cmd" getHex()
expAdd "crc_c16p1" getHex()
expAdd "crc_vcu16p1" getHex()
expAdd "crc_cmd16p1" getHex()
expAdd "crc_c16p2" getHex()
expAdd "crc_vcu16p2" getHex()
expAdd "crc_cmd16p2" getHex()
expAdd "crc_c32" getHex()
expAdd "crc_vcu32" getHex()
expAdd "crc_cmd32" getHex()
expAdd "err" getNatural()
