//Add watch window variables
expRemoveAll
expAdd "err" getNatural()

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/VCU/v110/examples_ccsv4/2806x_RIFFT_128p/2806x_RIFFT_128p.graphProp')
