//Add watch window variables
expRemoveAll
expAdd "rgen.freq" getQValue(15)        
expAdd "rgen.step_max" getNatural()     
expAdd "rgen.angle" getQValue(16)          
expAdd "rgen.gain" getQValue(15)        
expAdd "rgen.offset" getQValue(15)       
expAdd "rgen.out" getQValue(15)
openAnalysisView('Single Time','C:/TI/controlSUITE/libs/dsp/SGEN/v101/examples_ccsv4/2833x_RMPGEN/rampgen.graphProp')
