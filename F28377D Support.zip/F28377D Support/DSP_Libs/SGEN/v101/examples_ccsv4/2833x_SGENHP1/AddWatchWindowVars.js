//Add watch window variables
expRemoveAll
expAdd "sgen.freq" getQValue(31)
expAdd "sgen.step_max" getQValue(0)
expAdd "sgen.alpha" getQValue(16)
expAdd "sgen.gain" getQValue(15)
expAdd "sgen.offset" getQValue(15)
expAdd "sgen.out" getQValue(15)
openAnalysisView('Single Time','C:/TI/controlSUITE/libs/dsp/SGEN/v101/examples_ccsv4/2833x_SGENHP1/sgenhp1.graphProp')
