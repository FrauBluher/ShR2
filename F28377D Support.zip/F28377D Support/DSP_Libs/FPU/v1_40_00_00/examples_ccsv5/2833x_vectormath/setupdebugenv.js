//Add watch window variables
expRemoveAll()
expAdd("x1", getNatural())
expAdd("x2", getNatural())
expAdd("y", getNatural())
expAdd("c", getNatural())
expAdd("w1", getNatural())
expAdd("w2", getNatural())
expAdd("z", getNatural())
