//Add watch window variables
expRemoveAll()
expAdd("cfft", getNatural())

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/FPU/v1_40_00_00/examples_ccsv5/2833x_ICFFT/ICFFT_IN_OUT.graphProp')
openAnalysisView('Single Time','C:/TI/controlSUITE/libs/dsp/FPU/v1_40_00_00/examples_ccsv5/2833x_ICFFT/ICFFT_MAG.graphProp')
