//Add watch window variables
expRemoveAll()
expAdd("firFP", getNatural())

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/FPU/v1_40_00_00/examples_ccsv5/2833x_FIR/FIR.graphProp')
