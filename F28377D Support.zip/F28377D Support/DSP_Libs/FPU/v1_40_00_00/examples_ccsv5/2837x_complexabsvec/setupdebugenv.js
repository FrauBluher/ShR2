//Add watch window variables
expRemoveAll()
expAdd("x", getNatural())
expAdd("y", getNatural())
expAdd("p", getNatural())
expAdd("q", getNatural())
