//Add watch window variables
expRemoveAll
expAdd "rfft" getNatural()
expAdd "rfft_adc" getNatural()
expAdd "freq" getNatural()

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/FPU/v131/examples/2833x_RFFT_ADC_RT/RFFT_IN_OUT.graphProp')
openAnalysisView('Single Time','C:/TI/controlSUITE/libs/dsp/FPU/v131/examples/2833x_RFFT_ADC_RT/RFFT_MAG.graphProp')
