//Add watch window variables
expRemoveAll
expAdd "cfft" getNatural()

openAnalysisView('Dual Time','C:/TI/controlSUITE/libs/dsp/FPU/v131/examples/2833x_CFFT/CFFT_IN_OUT.graphProp')
openAnalysisView('Single Time','C:/TI/controlSUITE/libs/dsp/FPU/v131/examples/2833x_CFFT/CFFT_PHASE.graphProp')
