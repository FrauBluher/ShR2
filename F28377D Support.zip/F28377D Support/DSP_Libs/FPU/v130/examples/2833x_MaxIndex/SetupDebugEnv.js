//Add watch window variables
expRemoveAll
expAdd "x" getNatural()
expAdd "index" getNatural()
