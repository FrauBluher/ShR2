//Add watch window variables
expRemoveAll
expAdd "x" getNatural()
expAdd "w" getNatural()
expAdd "y" getNatural()
