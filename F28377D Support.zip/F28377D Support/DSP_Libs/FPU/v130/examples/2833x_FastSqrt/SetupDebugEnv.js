//Add watch window variables
expRemoveAll
expAdd "fInput" getNatural()
expAdd "fOutput" getNatural()


